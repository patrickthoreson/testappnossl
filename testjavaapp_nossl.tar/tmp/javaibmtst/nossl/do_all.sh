echo
export CLASSPATH=`pwd`/myJar.jar:`pwd`/postgresql-42.2.10.jar:.
echo $CLASSPATH
echo
javac PGConnect.java
jar -cf myJar.jar PGConnect.class
java PGConnect
